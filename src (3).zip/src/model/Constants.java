package model;

public class Constants {

	public static final String DATE_COLUMN_NAME = "Date";
	public static final String FIRSTNAME_COLUMN_NAME = "firstname";
	public static final String LASTNAME_COLUMN_NAME = "lastname";
	public static final String PAYRATE_COLUMN_NAME = "payrate";
	public static final String PUBLICHOLIDAY_PAYRATE_COLUMN_NAME = "publicholidayrate";
	public static final String QUANTITY_COLUMN_NAME ="Quantity";
	public static final String TOTAL_WORKED_HOURS_COLUMN_NAME ="WorkedHours";
	public static final String TO_BE_COMPARED_NAME ="ToBeComapred";
}
