package model;

public enum CellStyles {

		TOTAL_HOURS_STYLE,
		TOTAL_PAYOUT_STYLE,
		HOURS_MISMATCH_STYLE,
		NO_FILL_STYLE,
		PUBLIC_HOLIDAY_STYLE
}
