package inputoutput;

public interface IExcelFileWriter extends  IWriter{

	
}
