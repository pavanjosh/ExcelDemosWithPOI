package inputoutput;

import model.Model;

public interface IWriter {
	public void write(Model model, String destFile);
}
