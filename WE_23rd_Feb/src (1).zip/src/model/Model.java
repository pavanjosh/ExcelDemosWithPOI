package model;

import java.util.ArrayList;
import java.util.List;

public class Model {

	private List<String> missingNames = new ArrayList<String>();
	private ExcelSheet sheet = null;
	private List<Employee> employeeList = null;
	private List<String> diffInWorkingHoursNames = new ArrayList<String>();
	private List<Timesheet> timeSheetList = null;
	private List<String> peopleNotCompared = new ArrayList<String>();
	
	public List<String> getPeopleNotCompared() {
		return peopleNotCompared;
	}
	public void setPeopleNotCompared(List<String> peopleNotCompared) {
		this.peopleNotCompared = peopleNotCompared;
	}
	public ExcelSheet getSheet() {
		return sheet;
	}
	public void setSheet(ExcelSheet sheet) {
		this.sheet = sheet;
	}
	public List<Employee> getEmployeeList() {
		return employeeList;
	}
	public void setEmployeeList(List<Employee> employeeList) {
		this.employeeList = employeeList;
	}
	public void addMissingNames(String name) {
		missingNames.add(name);
		
	}
	public List<String> getMissingNames() {
		return missingNames;
	}
	public void setMissingNames(List<String> missingNames) {
		this.missingNames = missingNames;
	}
	public List<Timesheet> getTimeSheetList() {
		return timeSheetList;
	}
	public void setTimeSheetList(List<Timesheet> timeSheetList) {
		this.timeSheetList = timeSheetList;
	}
	public List<String> getDiffInWorkingHoursNames() {
		return diffInWorkingHoursNames;
	}
	public void setDiffInWorkingHoursNames(List<String> diffInWorkingHoursNames) {
		this.diffInWorkingHoursNames = diffInWorkingHoursNames;
	}
	
}
